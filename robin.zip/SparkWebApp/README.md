"# Arsw_Parcial2Robin" 




Servicio que alterna entre los dos servicios cuando esten montados en aws
donde resive la funcion y el numero y retorna el resultado de la operacion


![](IMG/SQRT.PNG)
![](IMG/SIN.PNG)
